/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agrodetecCargarimagen.vista;

import agrodetecCargarimagen.controlador.CargarImagenController; 
import agrodetecCargarimagen.modelo.ImagenDiagnostico;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.net.URL;
import javax.swing.*;
import javax.swing.border.TitledBorder;

/**
 * Vista para la carga de imágenes, visualización y despliegue del diagnóstico IA.
 * Nombre de clase: cargarimagen
 */
public class cargarimagen extends JFrame {

    // =========================================================================
    // DECLARACIÓN DE COMPONENTES
    // =========================================================================
    private FondoPanel fondoPanel;
    private JPanel panelPrincipal;
    
    private JLabel lblContenedorImagen;
    private JLabel lblRuta;
    private JTextArea txtResultado;
    
    private JButton btnCargarImagen;
    private JButton btnAnalizar;
    
    private File archivoImagenActual = null;
    
    // Controlador de la funcionalidad
    private CargarImagenController controller;

    // Colores y Estilos
    private final Color COLOR_PRIMARIO = new Color(50, 150, 50); 
    private final Color COLOR_SECUNDARIO = new Color(200, 230, 200);

    // =========================================================================
    // CONSTRUCTOR
    // =========================================================================
    
    public cargarimagen() {
        controller = new CargarImagenController();
        
        setTitle("AgroDetec - Carga y Diagnóstico");
        setSize(800, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initComponents();
    }

    private void initComponents() {
        // Inicializar el fondo con la imagen "fondo.jpg"
        fondoPanel = new FondoPanel("mundo verde.jpg");
        fondoPanel.setLayout(new GridBagLayout()); 
        setContentPane(fondoPanel);
        
        // Configurar el panel principal
        panelPrincipal = crearPanelPrincipal();
        fondoPanel.add(panelPrincipal);
        
        // Configurar eventos
        // Nota: Si usas la sintaxis 'this::metodo', no necesitas implementar ActionListener
        btnCargarImagen.addActionListener(this::cargarImagen);
        btnAnalizar.addActionListener(this::analizarImagen);
    }
    
    private JPanel crearPanelPrincipal() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setPreferredSize(new Dimension(650, 600));
        // Se asegura que el panel principal sea semi-transparente para ver el fondo
        panel.setBackground(new Color(255, 255, 255, 240)); 
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // --- Título ---
        JLabel lblTitulo = new JLabel("Diagnóstico de Plagas por Imagen");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblTitulo.setForeground(COLOR_PRIMARIO);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(lblTitulo, gbc);
        
        // --- 1. Contenedor de Imagen ---
        lblContenedorImagen = new JLabel("Click para Cargar Imagen", SwingConstants.CENTER);
        lblContenedorImagen.setPreferredSize(new Dimension(300, 300));
        lblContenedorImagen.setBackground(COLOR_SECUNDARIO);
        lblContenedorImagen.setOpaque(true);
        lblContenedorImagen.setBorder(BorderFactory.createLineBorder(COLOR_PRIMARIO, 2));
        lblContenedorImagen.setFont(new Font("SansSerif", Font.ITALIC, 14));
        
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        gbc.weightx = 0.5; gbc.weighty = 0.5;
        gbc.fill = GridBagConstraints.BOTH;
        panel.add(lblContenedorImagen, gbc);

        // --- 2. Panel de Resultados ---
        JPanel panelResultado = new JPanel(new BorderLayout(5, 5));
        panelResultado.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARIO), 
            "Resultado del Análisis IA", 
            TitledBorder.LEFT, 
            TitledBorder.TOP, 
            new Font("SansSerif", Font.BOLD, 16), 
            COLOR_PRIMARIO));

        txtResultado = new JTextArea("Esperando imagen para diagnóstico...");
        txtResultado.setFont(new Font("Monospaced", Font.PLAIN, 14));
        txtResultado.setEditable(false);
        txtResultado.setLineWrap(true);
        txtResultado.setWrapStyleWord(true);
        panelResultado.add(new JScrollPane(txtResultado), BorderLayout.CENTER);
        
        gbc.gridx = 1; gbc.gridy = 1; 
        panel.add(panelResultado, gbc);

        // --- 3. Ruta del Archivo (oculta) ---
        lblRuta = new JLabel("Archivo: Ninguno");
        lblRuta.setFont(new Font("SansSerif", Font.ITALIC, 10));
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        gbc.weighty = 0.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(lblRuta, gbc);

        // --- 4. Botones ---
        btnCargarImagen = new JButton("1. CARGAR IMAGEN (.jpg/.png)");
        btnAnalizar = new JButton("2. ANALIZAR CON IA");
        
        estilizarBoton(btnCargarImagen);
        estilizarBoton(btnAnalizar);
        btnAnalizar.setEnabled(false); // Desactivar hasta que haya imagen

        JPanel panelBotones = new JPanel(new GridLayout(1, 2, 15, 0));
        panelBotones.add(btnCargarImagen);
        panelBotones.add(btnAnalizar);
        
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(panelBotones, gbc);
        
        return panel;
    }
    
    // =========================================================================
    // CLASE INTERNA PARA EL FONDO DE PANTALLA
    // =========================================================================

    /**
     * Panel que dibuja la imagen de fondo escalada.
     */
    private class FondoPanel extends JPanel {
        private Image fondo;

        public FondoPanel(String nombreImagen) {
            try {
                // La ruta asume que "fondo.jpg" está en el mismo paquete que esta clase.
                URL location = getClass().getResource(nombreImagen); 
                if (location != null) {
                    this.fondo = new ImageIcon(location).getImage();
                } else {
                    System.err.println("Error: Imagen de fondo no encontrada. Verifique que '" + nombreImagen + "' esté en la carpeta 'vista'.");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (fondo != null) {
                // Dibujar la imagen de fondo escalada para cubrir todo el panel
                g.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }

    // =========================================================================
    // LÓGICA DE EVENTOS
    // =========================================================================
    
    /**
     * Abre un JFileChooser para que el usuario seleccione una imagen.
     */
    private void cargarImagen(ActionEvent e) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Seleccionar Imagen de Planta");
        
        // Filtrar solo archivos de imagen
        fileChooser.setFileFilter(new javax.swing.filechooser.FileFilter() {
            @Override
            public boolean accept(File f) {
                if (f.isDirectory()) return true;
                String name = f.getName().toLowerCase();
                return name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".png");
            }

            @Override
            public String getDescription() {
                return "Archivos de Imagen (*.jpg, *.png)";
            }
        });

        int result = fileChooser.showOpenDialog(this);
        
        if (result == JFileChooser.APPROVE_OPTION) {
            archivoImagenActual = fileChooser.getSelectedFile();
            mostrarImagen(archivoImagenActual);
            btnAnalizar.setEnabled(true);
            lblRuta.setText("Archivo: " + archivoImagenActual.getAbsolutePath());
            txtResultado.setText("Archivo cargado. Pulse 'ANALIZAR CON IA' para obtener el diagnóstico.");
        }
    }

    /**
     * Muestra la imagen seleccionada en el JLabel.
     */
    private void mostrarImagen(File archivo) {
        ImageIcon icon = new ImageIcon(archivo.getAbsolutePath());
        Image img = icon.getImage();
        
        // Esperar a que el componente se dibuje para obtener el tamaño correcto
        if (lblContenedorImagen.getWidth() > 0 && lblContenedorImagen.getHeight() > 0) {
            int anchoLabel = lblContenedorImagen.getWidth();
            int altoLabel = lblContenedorImagen.getHeight();
            
            // Usar Image.SCALE_SMOOTH para calidad
            Image imagenEscalada = img.getScaledInstance(anchoLabel, altoLabel, Image.SCALE_SMOOTH);
            lblContenedorImagen.setIcon(new ImageIcon(imagenEscalada));
            lblContenedorImagen.setText(""); // Ocultar el texto placeholder
        } else {
             // Caso de fallback o si se llama antes de que el layout se calcule
             lblContenedorImagen.setIcon(icon); 
             lblContenedorImagen.setText("");
        }
    }

    /**
     * Llama al controlador para que realice el análisis de la imagen.
     */
    private void analizarImagen(ActionEvent e) {
        if (archivoImagenActual != null) {
            try {
                // Llamar al controlador para el análisis simulado de la IA
                ImagenDiagnostico resultado = controller.analizarImagen(archivoImagenActual.getAbsolutePath());
                
                // Formatear y mostrar el resultado
                String output = String.format(
                    "--- INFORME IA ---\n" +
                    "%s\n" +
                    "Nivel de Confianza: %.2f%%\n" +
                    "------------------\n" +
                    "Recomendación: Consulte a un agrónomo y aplique tratamiento si el nivel de confianza es alto.", 
                    resultado.getResultadoDiagnostico(), 
                    resultado.getConfianza() * 100
                );
                
                txtResultado.setText(output);
                
            } catch (Exception ex) {
                txtResultado.setText("Error durante el análisis: " + ex.getMessage());
                ex.printStackTrace();
            }
        } else {
            txtResultado.setText("Por favor, cargue una imagen primero.");
        }
    }

    // =========================================================================
    // MÉTODOS AUXILIARES DE ESTILO
    // =========================================================================
    
    private void estilizarBoton(JButton boton) {
        boton.setFont(new Font("SansSerif", Font.BOLD, 14));
        boton.setForeground(Color.WHITE);
        boton.setBackground(COLOR_PRIMARIO); 
        boton.setFocusPainted(false); 
        
        // Efecto Hover
        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                boton.setBackground(new Color(70, 170, 70)); // Tono más oscuro
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                boton.setBackground(COLOR_PRIMARIO); 
            }
        });
    }

    // =========================================================================
    // MÉTODO MAIN para ejecución (solo para pruebas)
    // =========================================================================
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new cargarimagen().setVisible(true));
    }
}