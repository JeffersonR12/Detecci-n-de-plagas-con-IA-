/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agrodetecCargarimagen.controlador; 

// 1. Importar la entidad (POJO). Es necesario para el tipo de retorno.
import agrodetecCargarimagen.modelo.ImagenDiagnostico;

// 2. Importar el DAO. Es necesario para usar la instancia 'dao'.
import agrodetecCargarimagen.modelo.cargarimagenDAO;
import agrodeteclogin.model.agrodetec;

// [CORRECCIÓN]: Se eliminó el import innecesario:
// import agrodeteclogin.model.agrodetec; 

/**
 * Controlador para la funcionalidad de carga y análisis de imágenes.
 */
public class CargarImagenController {
    
    // Se usa el nombre de clase correcto (con minúsculas)
    private final cargarimagenDAO dao;

    public CargarImagenController() {
        // Instancia el DAO
        this.dao = new cargarimagenDAO();
    }

    /**
     * Procesa la imagen cargada y realiza el diagnóstico simulado por la IA.
     * @param rutaArchivo La ruta local del archivo de imagen.
     * @return El objeto ImagenDiagnostico con los resultados del análisis.
     */
    public ImagenDiagnostico analizarImagen(String rutaArchivo) {
        
        if (rutaArchivo == null || rutaArchivo.trim().isEmpty()) {
            ImagenDiagnostico error = new ImagenDiagnostico();
            error.setResultadoDiagnostico("Error: No se ha seleccionado ningún archivo.");
            error.setConfianza(0.0);
            return error;
        }
        
        // Delegar la lógica de "IA" al DAO
        return dao.obtenerDiagnosticoIA(rutaArchivo);
    }
}