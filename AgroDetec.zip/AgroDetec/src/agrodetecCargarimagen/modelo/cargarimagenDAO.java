/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package agrodetecCargarimagen.modelo;

import java.io.File;
import java.util.Random;

// [CORRECCIÓN CRÍTICA]: El import debe apuntar al paquete donde tienes 
// definida la clase ImagenDiagnostico, que asumimos es:
import agrodetecCargarimagen.modelo.ImagenDiagnostico; 

/**
 * DAO que simula la función de la Inteligencia Artificial para el diagnóstico de plagas.
 * Aquí iría la lógica de llamada a un modelo de Machine Learning real.
 * NOTA: Por convención de Java, el nombre de la clase debería ser CargarImagenDAO (PascalCase).
 */
public class cargarimagenDAO {
    
    private final String[] PLAGAS = {"Roya (Fungus)", "Minador de Hoja", "Mancha Negra (Bacteria)", "Saludable"};
    
    /**
     * Simula el análisis de la IA para obtener un diagnóstico.
     * La lógica se basa en un diagnóstico aleatorio para la simulación.
     * @param rutaArchivo Ruta del archivo (no usada en la simulación, pero necesaria para la estructura).
     * @return ImagenDiagnostico con el resultado.
     */
    public ImagenDiagnostico obtenerDiagnosticoIA(String rutaArchivo) {
        Random random = new Random();
        
        ImagenDiagnostico diagnostico = new ImagenDiagnostico();
        diagnostico.setRutaArchivo(rutaArchivo);

        // 1. Simular la detección y la confianza
        int indicePlaga = random.nextInt(PLAGAS.length);
        String resultado = PLAGAS[indicePlaga];
        double confianza = 0.70 + (0.29 * random.nextDouble()); // Confianza entre 70% y 99%
        
        // 2. Asignar los resultados
        diagnostico.setResultadoDiagnostico("Diagnóstico: " + resultado);
        diagnostico.setConfianza(confianza);
        
        return diagnostico;
    }
}