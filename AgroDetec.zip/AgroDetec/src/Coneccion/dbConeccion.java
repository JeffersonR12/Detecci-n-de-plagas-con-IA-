/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Coneccion;
import java.sql.*;
/**
 *
 * @author ACER
 */
public class dbConeccion {
   static String url="jdbc:sqlserver://localhost\\\\SQLDEVELOPER;databaseName=deteccion_plagas_ia";
   static String user="Usersql";
   static String pass="1234";
  
    public static Connection conectar()
    {
       Connection con=null;
       try
       {
       con=DriverManager.getConnection(url,user,pass);
           System.out.println("Conexión exitosa");
       }catch(SQLException e)
       {
        e.printStackTrace();
       }
       
       return con;
               
    } 
}
