package agrodeteclogin.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.net.URL;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;

/**
 * @author ACER (Modificado por Gemini para UI/UX)
 * Vista principal de Login para AgroDetec.
 * Usa Absolute Layout y carga de recursos directa desde el paquete 'view'.
 */
public class AgroDetecj extends JFrame {

    // =========================================================================
    // 2. DECLARACIÓN DE COMPONENTES
    // =========================================================================
    
    private JPanel panelLogin;
    private FondoPanel fondoPanel; // Panel personalizado para el fondo
    
    private JLabel lblLogo;
    private JLabel lblTitulo;
    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JButton btnIngresar;

    // Colores y Estilos
    private final Color COLOR_PRIMARIO = new Color(50, 150, 50); // Verde agrícola
    private final Color COLOR_SECUNDARIO = new Color(170, 200, 170); // Verde pálido (hover)
    private final Color COLOR_FONDO_LOGIN = new Color(255, 255, 255, 220); // Blanco semitransparente

    // =========================================================================
    // 3. CONSTRUCTOR
    // =========================================================================
    
    public AgroDetecj() {
        // Configuraciones básicas del JFrame
        setTitle("AgroDetec - Acceso al Sistema");
        setSize(500 , 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar ventana
        setResizable(false);
        
        initComponents();
    }

    /**
     * Inicializa y organiza todos los componentes de la interfaz de usuario.
     */
    private void initComponents() {
        // 4. Configurar el fondo de pantalla
        // Nota: Las imágenes están directamente en la carpeta 'view'
        fondoPanel = new FondoPanel("login.png");
        fondoPanel.setLayout(null); 
        setContentPane(fondoPanel);
        
        // 5. Crear y añadir el panel de login centrado
        panelLogin = crearPanelLogin();
        
        int panelAncho = 400;
        int panelAlto = 500;
        int x = (getWidth() - panelAncho) / 2;
        int y = (getHeight() - panelAlto) / 2;
        
        panelLogin.setBounds(x, y, panelAncho, panelAlto);
        fondoPanel.add(panelLogin);
    }
    
    // =========================================================================
    // 5. MÉTODO PARA CREAR EL PANEL DE LOGIN
    // =========================================================================

    private JPanel crearPanelLogin() {
        JPanel panel = new JPanel();
        panel.setLayout(null); 
        panel.setBackground(COLOR_FONDO_LOGIN);
        
        // Borde estilizado
        Border borderRedondeado = BorderFactory.createLineBorder(new Color(200, 200, 200), 1);
        panel.setBorder(BorderFactory.createCompoundBorder(
            borderRedondeado, 
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        // --- 1. Logo ---
        lblLogo = new JLabel();
        // Carga directa de logmaseta.png desde la carpeta 'view'
        cargarImagen(lblLogo, "logmaseta.png", 100, 100); 
        lblLogo.setBounds((400 - 100) / 2, 30, 100, 100); 
        panel.add(lblLogo);
        
        // --- 2. Título ---
        lblTitulo = new JLabel("AGRODETEC");
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 22));
        lblTitulo.setForeground(COLOR_PRIMARIO);
        Dimension dTitulo = lblTitulo.getPreferredSize();
        lblTitulo.setBounds((400 - dTitulo.width) / 2, 140, dTitulo.width, dTitulo.height);
        panel.add(lblTitulo);

        // --- 3. Campo de Usuario ---
        txtUsuario = new JTextField();
        estilizarCampo(txtUsuario, "Usuario");
        txtUsuario.setBounds(50, 190, 300, 40); 
        panel.add(txtUsuario);

        // --- 4. Campo de Contraseña ---
        txtContrasena = new JPasswordField();
        estilizarCampo(txtContrasena, "Contraseña");
        txtContrasena.setBounds(50, 260, 300, 40); 
        panel.add(txtContrasena);
        
        // --- 5. Botón de Ingreso ---
        btnIngresar = new JButton("INGRESAR");
        estilizarBoton(btnIngresar);
        btnIngresar.setBounds(50, 350, 300, 45); 
        panel.add(btnIngresar);

        // 7. Configurar Event Handler
        btnIngresar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                manejarIngreso();
            }
        });

        return panel;
    }

    // =========================================================================
    // 4. CLASE INTERNA PARA EL FONDO DE PANTALLA
    // =========================================================================

    /**
     * Panel que dibuja la imagen de fondo escalada.
     */
    private class FondoPanel extends JPanel {
        private Image fondo;

        public FondoPanel(String nombreImagen) {
            try {
                // CORRECCIÓN DE RUTA: Carga RELATIVA directa desde el paquete 'view'
                URL location = getClass().getResource(nombreImagen); 
                if (location != null) {
                    this.fondo = new ImageIcon(location).getImage();
                } else {
                    System.err.println("Error: Imagen de fondo no encontrada. Verifique que '" + nombreImagen + "' esté en la carpeta 'view'.");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (fondo != null) {
                // Dibujar la imagen de fondo escalada
                g.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }

    // =========================================================================
    // 6. MÉTODOS AUXILIARES DE ESTILO
    // =========================================================================

    /**
     * Carga y escala una imagen en un JLabel.
     */
    private void cargarImagen(JLabel label, String nombreArchivo, int ancho, int alto) {
        try {
            // CORRECCIÓN DE RUTA: Carga RELATIVA directa desde el paquete 'view'
            URL location = getClass().getResource(nombreArchivo);
            
            if (location != null) {
                ImageIcon icon = new ImageIcon(location);
                Image img = icon.getImage().getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
                label.setIcon(new ImageIcon(img));
            } else {
                label.setText("[Logo]"); 
                System.err.println("Error: Imagen de logo no encontrada. Verifique que '" + nombreArchivo + "' esté en la carpeta 'view'.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Estiliza el JTextfield/JPasswordField con placeholders.
     */
    private void estilizarCampo(JTextField campo, String placeholder) {
        campo.setText(placeholder); 
        campo.setForeground(Color.GRAY);
        campo.setFont(new Font("SansSerif", Font.PLAIN, 16));
        
        Border borde = BorderFactory.createLineBorder(COLOR_PRIMARIO, 2);
        Border padding = BorderFactory.createEmptyBorder(5, 10, 5, 10);
        campo.setBorder(BorderFactory.createCompoundBorder(borde, padding));
        
        // Listener para la funcionalidad Placeholder
        campo.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent evt) {
                if (campo.getText().equals(placeholder)) {
                    campo.setText("");
                    campo.setForeground(Color.BLACK);
                    if (campo instanceof JPasswordField) {
                        ((JPasswordField) campo).setEchoChar('*'); 
                    }
                }
            }
            @Override
            public void focusLost(FocusEvent evt) {
                if (campo.getText().isEmpty()) {
                    campo.setText(placeholder);
                    campo.setForeground(Color.GRAY);
                    if (campo instanceof JPasswordField) {
                        ((JPasswordField) campo).setEchoChar((char) 0); 
                    }
                }
            }
        });
        
        // Configuración inicial para ocultar el texto del placeholder en JPasswordField
        if (campo instanceof JPasswordField) {
            ((JPasswordField) campo).setEchoChar((char) 0); 
        }
    }
    
    /**
     * Estiliza el botón con efecto hover.
     */
    private void estilizarBoton(JButton boton) {
        boton.setFont(new Font("SansSerif", Font.BOLD, 18));
        boton.setForeground(Color.WHITE);
        boton.setBackground(COLOR_PRIMARIO); 
        boton.setFocusPainted(false); 
        boton.setBorder(BorderFactory.createLineBorder(COLOR_PRIMARIO, 1, true));

        // Efecto Hover
        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                boton.setBackground(COLOR_SECUNDARIO); 
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                boton.setBackground(COLOR_PRIMARIO); 
            }
        });
    }

    // =========================================================================
    // 7. EVENT HANDLERS (ActionListener)
    // =========================================================================

    /**
     * Maneja la lógica del botón Ingresar, incluyendo validación visual.
     */
    private void manejarIngreso() {
        String usuario = txtUsuario.getText();
        String contrasena = new String(txtContrasena.getPassword());
        
        // Reiniciar estilos de borde
        Border bordeDefault = BorderFactory.createLineBorder(COLOR_PRIMARIO, 2);
        Border padding = BorderFactory.createEmptyBorder(5, 10, 5, 10);
        
        txtUsuario.setBorder(BorderFactory.createCompoundBorder(bordeDefault, padding));
        txtContrasena.setBorder(BorderFactory.createCompoundBorder(bordeDefault, padding));

        // Validación de campos vacíos
        boolean camposVacios = false;
        Border bordeError = BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.RED, 2), padding);
        
        if (usuario.isEmpty() || usuario.equals("Usuario")) {
            txtUsuario.setBorder(bordeError); 
            camposVacios = true;
        }
        
        if (contrasena.isEmpty() || contrasena.equals("Contraseña")) {
            txtContrasena.setBorder(bordeError);
            camposVacios = true;
        }

        if (camposVacios) {
            JOptionPane.showMessageDialog(this, "Debe ingresar usuario y contraseña.", "Error de Validación", JOptionPane.WARNING_MESSAGE);
        } else {
            // Lógica de autenticación iría aquí
            JOptionPane.showMessageDialog(this, 
                "¡Bienvenido, " + usuario + "! Autenticación simulada exitosa.", 
                "Ingreso Exitoso", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    // =========================================================================
    // MÉTODO MAIN para ejecución
    // =========================================================================

    public static void main(String[] args) {
        // Ejecutar en el Event Dispatch Thread
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AgroDetecj().setVisible(true);
            }
        });
    }
}