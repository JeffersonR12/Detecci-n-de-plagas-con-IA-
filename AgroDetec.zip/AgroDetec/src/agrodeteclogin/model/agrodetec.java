/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agrodeteclogin.model;

/**
 * Entidad (POJO) principal para el usuario y la autenticación.
 * @author ACER
 */
public class agrodetec {
    
    // Atributos básicos para la autenticación
    private String usuario;
    private String contrasena;
    private int idUsuario;
    private String nombreCompleto;

    // Constructor vacío
    public agrodetec() {
    }

    // Constructor completo (útil para crear objetos después de una consulta a la BD)
    public agrodetec(String usuario, String contrasena, int idUsuario, String nombreCompleto) {
        this.usuario = usuario;
        this.contrasena = contrasena;
        this.idUsuario = idUsuario;
        this.nombreCompleto = nombreCompleto;
    }

    // Getters y Setters

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }
    
    // ¡TODO EL CÓDIGO DE LAS CLASES ANIDADAS SE ELIMINA DE AQUÍ!
    // Esto fuerza a que el compilador solo use las clases que definiste en agrodetecCargarimagen.modelo
}
