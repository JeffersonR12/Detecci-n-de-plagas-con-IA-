/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agrodeteclogin.model;

// Se debe importar el paquete donde se encuentra la clase de conexión
import Coneccion.dbConeccion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Data Access Object (DAO) para manejar las operaciones de autenticación de Usuarios.
 * Utiliza la clase dbConeccion para interactuar con la base de datos SQL Server.
 */
public class agrodetecDAO {

    /**
     * Valida el usuario y contraseña contra la base de datos 'deteccion_plagas_ia'.
     * @param usuario El nombre de usuario ingresado.
     * @param contrasena La contraseña ingresada.
     * @return true si las credenciales coinciden con un registro, false en caso contrario.
     */
    public boolean validarCredenciales(String usuario, String contrasena) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean autenticado = false;
        
        // Define la consulta SQL para buscar el usuario y la contraseña
        // ASUNCIÓN: La tabla de usuarios se llama 'usuarios' y tiene columnas 'usuario' y 'contrasena'.
        String sql = "SELECT COUNT(*) FROM usuarios WHERE usuario = ? AND contrasena = ?"; 
        
        try {
            // 1. Obtener la conexión a la base de datos
            con = dbConeccion.conectar();
            
            if (con != null) {
                // 2. Preparar la consulta
                ps = con.prepareStatement(sql);
                ps.setString(1, usuario);
                ps.setString(2, contrasena); // ¡RECORDATORIO: En producción, usar hashing para contraseñas!
                
                // 3. Ejecutar la consulta
                rs = ps.executeQuery();
                
                // 4. Procesar el resultado
                if (rs.next()) {
                    // Si COUNT(*) es mayor que 0, significa que se encontró una coincidencia.
                    if (rs.getInt(1) > 0) {
                        autenticado = true;
                    }
                }
            } else {
                System.err.println("La conexión a la base de datos es nula.");
            }
            
        } catch (SQLException e) {
            System.err.println("Error de SQL al intentar autenticar: " + e.getMessage());
        } finally {
            // 5. Cerrar los recursos (ResultSet, PreparedStatement, Connection)
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (SQLException ex) {
                System.err.println("Error al cerrar recursos: " + ex.getMessage());
            }
        }
        
        return autenticado;
    }
    
    // Aquí irían otros métodos DAO (ej: buscar datos del usuario, registrar nuevo usuario, etc.)
}
