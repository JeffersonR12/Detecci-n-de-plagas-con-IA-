/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agrodeteclogin.controller;

// IMPORTS NECESARIOS
import agrodetecCargarimagen.vista.cargarimagen; // 1. Importar la Vista de Carga de Imagen
import javax.swing.JFrame; // 2. Necesario para manejar la ventana de login
import agrodeteclogin.model.agrodetecDAO;

/**
 * @author ACER
 */
public class agrodetecController {
    
    private agrodetecDAO dao;

    public agrodetecController() {
        // Inicializar el Objeto de Acceso a Datos
        this.dao = new agrodetecDAO();
    }

    /**
     * Recibe credenciales de la Vista, delega la validación al DAO y maneja la navegación.
     * @param usuario El usuario ingresado.
     * @param contrasena La contraseña ingresada.
     * @param vistaLogin La instancia de la ventana de login actual (para poder cerrarla).
     * @return true si la autenticación fue exitosa.
     */
    public boolean autenticarUsuarioYNavegar(String usuario, String contrasena, JFrame vistaLogin) {
        
        // Delegar la validación al DAO
        boolean exito = dao.validarCredenciales(usuario, contrasena);
        
        if (exito) {
            // --- LÓGICA DE NAVEGACIÓN ---
            
            // 1. Cerrar la ventana de Login
            vistaLogin.dispose(); 
            
            // 2. Abrir la nueva ventana de Carga de Imagen
            cargarimagen vistaCargarImagen = new cargarimagen();
            vistaCargarImagen.setVisible(true);
        }
        
        return exito;
    }
}